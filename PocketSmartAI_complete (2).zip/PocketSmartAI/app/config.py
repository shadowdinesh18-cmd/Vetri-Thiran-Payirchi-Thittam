import os
from pathlib import Path
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent.parent
load_dotenv(ROOT / '.env')

class Settings:
    app_name = 'PocketSmart AI'
    secret_key = os.getenv('SECRET_KEY', 'dev-only-change-me')
    access_token_expire_minutes = int(os.getenv('ACCESS_TOKEN_EXPIRE_MINUTES', '1440'))
    database_path = str((ROOT / os.getenv('DATABASE_PATH', 'app/data/pocketsmart.db')).resolve()) if not os.getenv('DATABASE_PATH','').startswith('/') else os.getenv('DATABASE_PATH')
    gemini_api_key = os.getenv('GEMINI_API_KEY', '')
    gemini_model = os.getenv('GEMINI_MODEL', 'gemini-2.5-flash')
    max_upload_mb = int(os.getenv('MAX_UPLOAD_MB', '8'))
    upload_dir = ROOT / 'uploads'

settings = Settings()
settings.upload_dir.mkdir(parents=True, exist_ok=True)
Path(settings.database_path).parent.mkdir(parents=True, exist_ok=True)
