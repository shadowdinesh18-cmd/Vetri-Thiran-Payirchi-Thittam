import sqlite3, json
from contextlib import contextmanager
from datetime import datetime, timezone
from .config import settings

@contextmanager
def connect():
    conn = sqlite3.connect(settings.database_path)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()

def init_db():
    with connect() as c:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS recommendations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            type TEXT NOT NULL,
            input_json TEXT NOT NULL,
            result_json TEXT NOT NULL,
            created_at TEXT NOT NULL
        );
        ''')

def create_user(username, email, password_hash):
    with connect() as c:
        c.execute('INSERT INTO users(username,email,password_hash,created_at) VALUES(?,?,?,?)', (username,email,password_hash,datetime.now(timezone.utc).isoformat()))

def get_user(username):
    with connect() as c:
        return c.execute('SELECT * FROM users WHERE username=?', (username,)).fetchone()

def save_recommendation(username, rec_type, input_data, result):
    now = datetime.now(timezone.utc).isoformat()
    with connect() as c:
        cur = c.execute('INSERT INTO recommendations(username,type,input_json,result_json,created_at) VALUES(?,?,?,?,?)', (username,rec_type,json.dumps(input_data),json.dumps(result),now))
        return cur.lastrowid

def list_recommendations(username):
    with connect() as c:
        rows = c.execute('SELECT * FROM recommendations WHERE username=? ORDER BY id DESC', (username,)).fetchall()
        return [dict(r) for r in rows]

def get_recommendation(username, rec_id):
    with connect() as c:
        r = c.execute('SELECT * FROM recommendations WHERE username=? AND id=?', (username,rec_id)).fetchone()
        return dict(r) if r else None
