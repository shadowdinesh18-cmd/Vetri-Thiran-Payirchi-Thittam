from typing import Optional, List
from pydantic import BaseModel, Field

class RegisterInput(BaseModel):
    username: str = Field(min_length=3, max_length=30, pattern=r'^[A-Za-z0-9_.-]+$')
    email: str
    password: str = Field(min_length=6, max_length=128)

class LoginInput(BaseModel):
    username: str
    password: str

class HomeBudgetInput(BaseModel):
    total_budget: float = Field(gt=0)
    rooms: List[str] = ['Living Room']
    num_lights: int = Field(default=5, ge=0, le=100)
    num_fans: int = Field(default=2, ge=0, le=100)
    num_furniture: int = Field(default=2, ge=0, le=100)
    num_dining_tables: int = Field(default=1, ge=0, le=20)
    requirements: Optional[str] = None

class PartyBudgetInput(BaseModel):
    total_budget: float = Field(gt=0)
    party_type: str = 'Birthday'
    venue_type: str = 'Indoor'
    num_guests: int = Field(gt=0, le=10000)
    needs: List[str] = []
    requirements: Optional[str] = None

class JewelryBudgetInput(BaseModel):
    total_budget: float = Field(gt=0)
    occasion: str = 'Birthday'
    preferences: Optional[str] = None
