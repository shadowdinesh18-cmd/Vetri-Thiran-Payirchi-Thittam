from pathlib import Path
import uuid
from fastapi import FastAPI, Request, Depends, HTTPException, status, UploadFile, File, Form
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from .config import settings
from .db import init_db, create_user, get_user, save_recommendation, list_recommendations, get_recommendation
from .security import hash_password, verify_password, create_token, get_username, COOKIE_NAME
from .models import RegisterInput, LoginInput, HomeBudgetInput, PartyBudgetInput, JewelryBudgetInput
from .services.recommender import home, party, jewelry, add_links

BASE=Path(__file__).resolve().parent
templates=Jinja2Templates(directory=str(BASE/'templates'))
app=FastAPI(title='PocketSmart AI', version='1.0.0')
app.mount('/static', StaticFiles(directory=str(BASE/'static')), name='static')
app.mount('/uploads', StaticFiles(directory=str(settings.upload_dir)), name='uploads')

@app.on_event('startup')
def startup(): init_db()

def current_user(request: Request):
    username=get_username(request)
    if not username: raise HTTPException(status_code=401, detail='Authentication required')
    u=get_user(username)
    if not u: raise HTTPException(status_code=401, detail='User not found')
    return dict(u)

def page_user(request):
    username=get_username(request)
    return dict(get_user(username)) if username and get_user(username) else None

def page(name, request, **ctx):
    return templates.TemplateResponse(name, {'request':request,'user':page_user(request), **ctx})

@app.get('/', response_class=HTMLResponse)
def index(request: Request): return page('index.html',request)
@app.get('/login', response_class=HTMLResponse)
def login_page(request: Request): return page('login.html',request)
@app.get('/register', response_class=HTMLResponse)
def register_page(request: Request): return page('register.html',request)
@app.get('/dashboard', response_class=HTMLResponse)
def dashboard(request: Request):
    try: current_user(request)
    except HTTPException: return RedirectResponse('/login',303)
    return page('dashboard.html',request)
@app.get('/home-planner', response_class=HTMLResponse)
def home_page(request: Request):
    try: current_user(request)
    except HTTPException: return RedirectResponse('/login',303)
    return page('home_planner.html',request)
@app.get('/party-planner', response_class=HTMLResponse)
def party_page(request: Request):
    try: current_user(request)
    except HTTPException: return RedirectResponse('/login',303)
    return page('party_planner.html',request)
@app.get('/jewelry-planner', response_class=HTMLResponse)
def jewelry_page(request: Request):
    try: current_user(request)
    except HTTPException: return RedirectResponse('/login',303)
    return page('jewelry_planner.html',request)
@app.get('/history', response_class=HTMLResponse)
def history_page(request: Request):
    try: current_user(request)
    except HTTPException: return RedirectResponse('/login',303)
    return page('history.html',request)
@app.get('/recommendation/{rec_id}', response_class=HTMLResponse)
def recommendation_page(request: Request, rec_id:int):
    try: u=current_user(request)
    except HTTPException: return RedirectResponse('/login',303)
    r=get_recommendation(u['username'],rec_id)
    if not r: raise HTTPException(404,'Recommendation not found')
    import json
    return page('recommendation.html',request, recommendation=r, result=json.loads(r['result_json']), input_data=json.loads(r['input_json']))

@app.get('/health')
def health(): return {'status':'ok','service':'PocketSmart AI','ai_mode':'gemini' if settings.gemini_api_key else 'demo'}

@app.post('/api/register')
def register(data:RegisterInput):
    if get_user(data.username) or _email_exists(data.email): raise HTTPException(409,'Username or email already exists')
    create_user(data.username,data.email,hash_password(data.password))
    return {'message':'Account created'}

def _email_exists(email):
    from .db import connect
    with connect() as c: return c.execute('SELECT 1 FROM users WHERE email=?',(email,)).fetchone() is not None

@app.post('/api/login')
def login(data:LoginInput):
    u=get_user(data.username)
    if not u or not verify_password(data.password,u['password_hash']): raise HTTPException(401,'Incorrect username or password')
    token=create_token(u['username']); response=JSONResponse({'message':'Logged in','username':u['username']})
    response.set_cookie(COOKIE_NAME,token,httponly=True,samesite='lax',max_age=settings.access_token_expire_minutes*60)
    return response

@app.post('/api/logout')
def logout():
    r=JSONResponse({'message':'Logged out'}); r.delete_cookie(COOKIE_NAME); return r

@app.get('/api/me')
def me(request:Request): return current_user(request)

@app.post('/api/home-budget')
async def home_budget(data:HomeBudgetInput, request:Request):
    u=current_user(request); result=add_links(await home(data),'home'); rid=save_recommendation(u['username'],'home',data.model_dump(),result); result['recommendation_id']=rid; return result

@app.post('/api/party-budget')
async def party_budget(data:PartyBudgetInput, request:Request):
    u=current_user(request); result=add_links(await party(data),'party'); rid=save_recommendation(u['username'],'party',data.model_dump(),result); result['recommendation_id']=rid; return result

@app.post('/api/jewelry-budget')
async def jewelry_budget(request:Request, total_budget:float=Form(...), occasion:str=Form(...), preferences:str=Form(''), image:UploadFile|None=File(None)):
    u=current_user(request)
    if total_budget<=0: raise HTTPException(422,'Budget must be greater than zero')
    image_bytes=None; image_name=None
    if image and image.filename:
        data=await image.read()
        if len(data)>settings.max_upload_mb*1024*1024: raise HTTPException(413,'Image is too large')
        ext=Path(image.filename).suffix.lower() or '.jpg'; name=f'{uuid.uuid4().hex}{ext}'
        (settings.upload_dir/name).write_bytes(data); image_name=name; image_bytes=data
    inp=JewelryBudgetInput(total_budget=total_budget,occasion=occasion,preferences=preferences or None)
    result=add_links(await jewelry(inp,image_bytes,image_name),'jewelry')
    if image_name: result['outfit_image_url']=f'/uploads/{image_name}'
    rid=save_recommendation(u['username'],'jewelry',inp.model_dump()|({'image':image.filename} if image and image.filename else {}),result); result['recommendation_id']=rid; return result

@app.get('/api/recommendation-history')
def history(request:Request):
    u=current_user(request); import json
    out=[]
    for r in list_recommendations(u['username']):
        result=json.loads(r['result_json']); inp=json.loads(r['input_json'])
        out.append({'id':r['id'],'type':r['type'],'created_at':r['created_at'],'input':inp,'summary':{'budget':result.get('total_budget'), 'remaining':result.get('remaining_budget')}})
    return out

@app.get('/api/recommendation/{rec_id}')
def recommendation_api(rec_id:int,request:Request):
    u=current_user(request); r=get_recommendation(u['username'],rec_id)
    if not r: raise HTTPException(404,'Recommendation not found')
    import json
    return {'id':r['id'],'type':r['type'],'created_at':r['created_at'],'input':json.loads(r['input_json']),'result':json.loads(r['result_json'])}
